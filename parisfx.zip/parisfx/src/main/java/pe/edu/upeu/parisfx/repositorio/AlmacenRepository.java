package pe.edu.upeu.parisfx.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.parisfx.modelo.Almacen;

public interface AlmacenRepository extends JpaRepository<Almacen, Long> {
}
