package pe.edu.upeu.parisfx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParisfxApplicationTests {

	@Test
	void contextLoads() {
	}

}
